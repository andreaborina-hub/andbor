# 📈 Market Agent v2 — Con AI Chat funzionante

## 🚀 Come fare il deploy su Netlify

### Step 1 — Carica il progetto su GitHub
1. Vai su **github.com** → registrati gratis
2. Clicca **"New repository"** → dai un nome tipo `market-agent`
3. Carica tutti i file di questa cartella

### Step 2 — Collega a Netlify
1. Vai su **app.netlify.com**
2. Clicca **"Add new site"** → **"Import an existing project"**
3. Scegli **GitHub** → seleziona il repository `market-agent`
4. Build command: `npm run build`
5. Publish directory: `build`
6. Clicca **Deploy**

### Step 3 — Aggiungi la API Key di Anthropic ⚠️ IMPORTANTE
Senza questo step la chat AI non funziona!

1. Nel tuo progetto Netlify vai su **Site settings**
2. Clicca **Environment variables** nel menu a sinistra
3. Clicca **"Add a variable"**
4. Key: `ANTHROPIC_API_KEY`
5. Value: la tua API key di Anthropic (da console.anthropic.com)
6. Clicca **Save**
7. Vai su **Deploys** → **"Trigger deploy"** per riavviare

### Step 4 — Installa sul telefono
Apri il link Netlify dal telefono:
- **iPhone**: Safari → Condividi → "Aggiungi a schermata Home"
- **Android**: Chrome → 3 puntini → "Aggiungi a schermata Home"

## ⚙️ Variabili d'ambiente necessarie
| Variabile | Valore |
|-----------|--------|
| `ANTHROPIC_API_KEY` | La tua key da console.anthropic.com |

## 📝 Note
- Alpha Vantage key è già nel codice (src/App.jsx)
- Piano gratuito Alpha Vantage: 25 req/giorno
- Solo a scopo educativo, non consulenza finanziaria
